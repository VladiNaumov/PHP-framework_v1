<h1>Подключён файл: Main->index.php</h1>
<code><?=__FILE__?></code>

<br>

<?= $hi ?>

<br>

<?= $name ?>

<br>

<?php

debug($colors);

?>