<?php

namespace app\controllers;

use vendor\core\base\Controller;

class App extends Controller
{

}