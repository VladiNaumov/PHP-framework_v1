<?php

namespace app\controllers;


class DemoController extends App
{

   // public $layout = 'main';

    public function indexAction()
    {

        // пример как сделать что-бы шаблон не подключался
        //$this->layout = false;

    }

}