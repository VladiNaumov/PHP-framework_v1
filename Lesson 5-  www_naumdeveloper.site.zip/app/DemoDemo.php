<?php

namespace app;

class DemoDemo
{
    public int $age ;
    public String $name ;

    /**
     * @param $age
     * @param $name
     */
    public function __construct()
    {
        $this->age = 27;
        $this->name = 'Halli';
    }


    public function myDemo()
    {

    }

    public static function myStaticDemo()
    {

    }

}