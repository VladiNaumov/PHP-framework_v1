<?php

namespace app\models;

use vendor\core\base\Model;

class Main extends Model
{

    public $table = 'posts';

}