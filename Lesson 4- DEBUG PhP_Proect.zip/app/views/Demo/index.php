<h1>Подключён файл Demo/index.php</h1>
<code><?=__FILE__?></code>