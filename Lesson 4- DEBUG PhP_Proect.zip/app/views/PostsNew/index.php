<h1>Подключён файл PostsNew/index.php</h1>
<code><?=__FILE__?></code>
