<h1>Подключён файл Posts/index.php</h1>
<code><?=__FILE__?></code>
