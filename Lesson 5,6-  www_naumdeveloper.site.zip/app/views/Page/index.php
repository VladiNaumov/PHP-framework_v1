<h1>Подключён файл: Page->index.php</h1>
<code><?=__FILE__?></code>
